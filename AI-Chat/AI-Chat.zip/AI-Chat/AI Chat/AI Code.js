const $c = $container;

$c.html(`
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .chat-wrap {
    display: flex; flex-direction: column; height: 100%;
    padding: 14px; gap: 10px;
    font-family: var(--font-family, sans-serif);
    color: var(--main-text-color);
  }
  .chat-ctx {
    display: flex; align-items: center; gap: 6px;
    padding: 10px 14px;
    background: var(--accented-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 6px; font-size: 17px;
    color: var(--muted-text-color);
  }
  .chat-ctx input {
    flex: 1; border: none; background: transparent;
    color: var(--main-text-color); font-size: 17px; outline: none;
  }
  .chat-ctx button {
    padding: 2px 8px; font-size: 17px; cursor: pointer;
    background: var(--button-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 4px; color: var(--main-text-color);
  }
  .chat-ctx button:hover { filter: brightness(1.1); }
  .chat-label { font-size: 17px; white-space: nowrap; opacity: 0.7; }
  .chat-ctx-title {
    font-size: 17px; font-weight: 600;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    max-width: 200px;
  }

  /* ── Persona / System prompt ── */
  .chat-persona {
    display: flex; flex-direction: column; gap: 6px;
    padding: 10px 14px;
    background: var(--accented-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 6px;
  }
  .persona-row {
    display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
  }
  .persona-row select {
    flex: 1; min-width: 0;
    padding: 4px 8px; font-size: 16px;
    background: var(--button-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 4px; color: var(--main-text-color);
    cursor: pointer;
  }
  .persona-row select:focus { outline: none; border-color: var(--main-color, #448); }
  .btn-persona-toggle {
    padding: 4px 10px; cursor: pointer; font-size: 13.5px;
    background: var(--button-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 4px; color: var(--muted-text-color);
    white-space: nowrap; transition: filter 0.1s;
  }
  .btn-persona-toggle:hover { filter: brightness(1.1); }
  .persona-prompt-wrap { display: none; }
  .persona-prompt-wrap.open { display: block; }
  .persona-prompt-wrap textarea {
    width: 100%; padding: 8px 10px; font-size: 16px; resize: vertical;
    border: 1px solid var(--main-border-color); border-radius: 5px;
    background: var(--accented-background-color);
    color: var(--main-text-color);
    font-family: inherit; line-height: 1.45; min-height: 72px;
  }
  .persona-prompt-wrap textarea:focus { outline: none; border-color: var(--main-color, #448); }
  .persona-hint { font-size: 12.5px; color: var(--muted-text-color); opacity: 0.8; margin-top: 3px; }

  /* ── Barra de comandos rápidos ── */
  .chat-cmds {
    display: flex; align-items: center; gap: 6px; flex-wrap: wrap;
    padding: 8px 12px;
    background: var(--accented-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 6px;
  }
  .btn-cmd {
    padding: 4px 11px; cursor: pointer; font-size: 13.5px;
    background: var(--button-background-color);
    border: 1px solid var(--main-border-color);
    border-radius: 4px; color: var(--main-text-color);
    white-space: nowrap; transition: filter 0.1s;
  }
  .btn-cmd:hover:not(:disabled) { filter: brightness(1.15); }
  .btn-cmd:disabled { opacity: 0.45; cursor: not-allowed; }

  .chat-messages {
    flex: 1; overflow-y: auto; min-height: 180px;
    border: 1px solid var(--main-border-color);
    border-radius: 6px; padding: 10px;
    display: flex; flex-direction: column; gap: 10px;
  }
  .msg { display: flex; flex-direction: column; gap: 3px; }
  .msg-label { font-size: 17px; font-weight: 700; opacity: 0.55; text-transform: uppercase; letter-spacing: 0.04em; }
  .msg-body { font-size: 17px; line-height: 1.55; white-space: pre-wrap; }
  .msg-user .msg-label { color: var(--main-color, #448); }
  .msg-ai .msg-label { color: var(--muted-text-color); }
  .msg-ai .msg-body {
    padding: 8px 10px;
    background: var(--accented-background-color);
    border-left: 3px solid var(--main-color, #448);
    border-radius: 0 4px 4px 0;
  }
  .msg-error .msg-body { color: #c0392b; font-style: italic; }
  .msg-system .msg-body { font-size: 17px; text-align: center; opacity: 0.45; font-style: italic; }
  .chat-footer { display: flex; gap: 8px; align-items: flex-end; }
  .chat-footer textarea {
    flex: 1; padding: 8px 10px; font-size: 17px; resize: none;
    border: 1px solid var(--main-border-color); border-radius: 6px;
    background: var(--accented-background-color);
    color: var(--main-text-color);
    font-family: inherit; line-height: 1.4;
  }
  .chat-footer textarea:focus { outline: none; border-color: var(--main-color, #448); }
  .chat-actions { display: flex; flex-direction: column; gap: 5px; }
  .btn-send {
    padding: 7px 14px; cursor: pointer; border: none;
    border-radius: 5px; font-size: 17px; font-weight: 600; white-space: nowrap;
    background: var(--main-color, #4477aa); color: #fff;
  }
  .btn-send:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn-send:not(:disabled):hover { filter: brightness(1.1); }
  .btn-save {
    padding: 7px 14px; cursor: pointer;
    border-radius: 5px; font-size: 17px; font-weight: 600; white-space: nowrap;
    background: var(--button-background-color);
    border: 1px solid var(--main-border-color);
    color: var(--main-text-color);
  }
  .btn-save:hover { filter: brightness(1.1); }
  .btn-clear {
    background: none; border: none; cursor: pointer;
    font-size: 17px; color: var(--muted-text-color);
    padding: 2px 4px; align-self: flex-end;
  }
  .typing { display: none; font-size: 17px; color: var(--muted-text-color); font-style: italic; }
  .typing.visible { display: block; }
</style>

<div class="chat-wrap">
  <div class="chat-ctx">
    <span class="chat-label">Contexto:</span>
    <span class="chat-ctx-title" id="ctx-title">nenhum</span>
    <input id="ctx-id-input" placeholder="ID da nota..." />
    <button id="btn-load">Carregar</button>
    <button id="btn-active">Nota ativa</button>
  </div>

  <!-- ── Persona / System Prompt ── -->
  <div class="chat-persona">
    <div class="persona-row">
      <span class="chat-label">Especialista:</span>
      <select id="persona-select"></select>
      <button class="btn-persona-toggle" id="btn-persona-toggle">✏️ Editar</button>
    </div>
    <div class="persona-prompt-wrap" id="persona-prompt-wrap">
      <textarea id="system-prompt-input" rows="3" placeholder="Prompt de sistema personalizado..."></textarea>
      <div class="persona-hint">Este texto substitui o prompt de sistema padrão em todas as interações.</div>
    </div>
  </div>

  <div class="chat-cmds">
    <span class="chat-label">Gerar:</span>
    <button class="btn-cmd" id="btn-cmd-resumo">📄 Resumo</button>
    <button class="btn-cmd" id="btn-cmd-mermaid">🔀 Mermaid</button>
    <button class="btn-cmd" id="btn-cmd-insights">💡 Insights</button>
    <button class="btn-cmd" id="btn-cmd-slides">🖥️ Slides</button>
  </div>

  <div class="chat-messages" id="messages">
    <div class="msg msg-system"><div class="msg-body">Carregue uma nota como contexto e faça sua pergunta — ou use os botões acima para gerar notas filhas.</div></div>
  </div>
  <span class="typing" id="typing">IA digitando...</span>
  <div class="chat-footer">
    <textarea id="user-input" rows="2" placeholder="Digite sua pergunta... (Ctrl+Enter para enviar)"></textarea>
    <div class="chat-actions">
      <button class="btn-send" id="btn-send">Enviar</button>
      <button class="btn-save" id="btn-save">Salvar nota</button>
      <button class="btn-clear" id="btn-clear">Limpar</button>
    </div>
  </div>
</div>
`);

// ── Estado ──────────────────────────────────────────────────────────────────
let history = [];
let ctxNoteId = null;

// ── Personas / Especialistas ─────────────────────────────────────────────────
const PERSONAS = [
  {
    id: 'default',
    label: '🤖 Assistente geral',
    prompt: 'Você é um assistente de conhecimento pessoal integrado ao Trilium Notes. Seja claro e conciso.'
  },
  {
    id: 'researcher',
    label: '🔬 Pesquisador',
    prompt: 'Você é um pesquisador acadêmico rigoroso. Analise o conteúdo com profundidade, cite evidências, aponte lacunas e sugira fontes complementares. Use linguagem precisa e estruturada. Prefira respostas organizadas com subtópicos quando relevante.'
  },
  {
    id: 'teacher',
    label: '🎓 Professor',
    prompt: 'Você é um professor didático e paciente. Explique os conceitos de forma clara, usando analogias e exemplos práticos. Adapte a complexidade à pergunta e sempre verifique se o aluno entendeu antes de avançar. Incentive a curiosidade.'
  },
  {
    id: 'critic',
    label: '🧐 Crítico',
    prompt: 'Você é um crítico analítico e construtivo. Identifique pontos fracos, premissas questionáveis, contradições e argumentos que precisam de reforço. Seja direto mas justo. Ao apontar problemas, sugira melhorias concretas.'
  },
  {
    id: 'programmer',
    label: '💻 Programador',
    prompt: 'Você é um engenheiro de software sênior. Ao responder, prefira código funcional, explique decisões arquiteturais, aponte trade-offs e siga boas práticas. Use blocos de código com a linguagem especificada. Seja preciso e pragmático.'
  },
  {
    id: 'writer',
    label: '✍️ Escritor',
    prompt: 'Você é um escritor e editor experiente. Ajude a estruturar ideias, melhorar clareza, ritmo e coesão textual. Sugira reformulações quando necessário. Valorize a voz original do autor enquanto eleva a qualidade do texto.'
  },
  {
    id: 'socratic',
    label: '💬 Socrático',
    prompt: 'Você é um facilitador socrático. Em vez de dar respostas diretas, faça perguntas que estimulem a reflexão e levem o interlocutor a descobrir as respostas por si mesmo. Desafie premissas gentilmente. Só forneça a resposta direta se explicitamente solicitado.'
  },
  {
    id: 'custom',
    label: '⚙️ Personalizado',
    prompt: ''
  }
];

// Popula o select de personas
const $personaSelect = $c.find('#persona-select');
PERSONAS.forEach(function(p) {
  $personaSelect.append($('<option>').val(p.id).text(p.label));
});

// Preenche o textarea quando o select muda
$personaSelect.on('change', function() {
  const pid = $(this).val();
  const persona = PERSONAS.find(function(p) { return p.id === pid; });
  if (persona && pid !== 'custom') {
    $c.find('#system-prompt-input').val(persona.prompt);
  }
  // Se "Personalizado", mantém o que o usuário já digitou
});

// Inicializa com a persona padrão
$c.find('#system-prompt-input').val(PERSONAS[0].prompt);

// Toggle do campo de edição
$c.find('#btn-persona-toggle').on('click', function() {
  const $wrap = $c.find('#persona-prompt-wrap');
  const open = $wrap.hasClass('open');
  $wrap.toggleClass('open', !open);
  $(this).text(open ? '✏️ Editar' : '🔼 Fechar');
});

// Quando o usuário edita manualmente, muda o select para "Personalizado"
$c.find('#system-prompt-input').on('input', function() {
  const currentId = $personaSelect.val();
  const persona = PERSONAS.find(function(p) { return p.id === currentId; });
  // Se o texto diverge da persona selecionada, marca como personalizado
  if (persona && persona.id !== 'custom' && $(this).val() !== persona.prompt) {
    $personaSelect.val('custom');
  }
});

// Helper: obtém o system prompt atual
function getSystemPrompt() {
  return $c.find('#system-prompt-input').val().trim() ||
    'Você é um assistente de conhecimento pessoal integrado ao Trilium Notes. Seja claro e conciso.';
}

// ── Definição dos comandos rápidos ──────────────────────────────────────────
const COMMANDS = [
  {
    id: 'resumo',
    label: '📄 Resumo',
    childTitle: (t) => 'Resumo — ' + t,
    prompt: `Crie um resumo completo desta nota preservando:
- O tema central e a linha argumentativa
- Todos os links e URLs mencionados (mantenha-os clicáveis como <a href="...">)
- A bibliografia e referências completas

Formate a resposta em HTML limpo usando <h2>, <p> e <ul> onde adequado.
Não inclua comentários introdutórios — comece direto pelo conteúdo.`,
    noteType: 'text',
    mime: null,
    process: (s) => s
  },
  {
    id: 'mermaid',
    label: '🔀 Mermaid',
    childTitle: (t) => 'Fluxo — ' + t,
    prompt: `Crie um diagrama Mermaid (flowchart LR, mindmap ou sequenceDiagram conforme o mais adequado) representando os conceitos e relações principais desta nota.
Retorne APENAS o código Mermaid puro, sem blocos de markdown (sem \`\`\`), sem explicações, sem texto adicional.`,
    noteType: 'code',
    mime: 'text/x-mermaid',
    process: (s) => s.replace(/^```(?:mermaid)?\r?\n?/i, '').replace(/\r?\n?```$/i, '').trim()
  },
  {
    id: 'insights',
    label: '💡 Insights',
    childTitle: (t) => 'Insights — ' + t,
    prompt: `A partir desta nota, gere:
1. Insights-chave e padrões não óbvios
2. Conexões com outros campos do conhecimento
3. Perguntas abertas que o conteúdo levanta
4. Possíveis pontos cegos ou limitações do argumento

Formate em HTML com <h3> para cada seção e <ul>/<li> para os itens.
Seja analítico e crítico, não apenas descritivo.`,
    noteType: 'text',
    mime: null,
    process: (s) => s
  },
  {
    id: 'slides',
    label: '🖥️ Slides',
    childTitle: (t) => 'Slides — ' + t,
    prompt: `Crie o conteúdo textual para uma apresentação de slides a partir desta nota.
Para cada slide use exatamente este formato HTML:

<section>
<h2>Título do Slide</h2>
<ul>
  <li>Ponto principal 1</li>
  <li>Ponto principal 2</li>
</ul>
<p><em>Nota do apresentador (opcional)</em></p>
</section>

Gere entre 6 e 10 slides, incluindo: slide de título, desenvolvimento e slide de conclusão.
Apenas texto — sem imagens, sem código, sem comentários fora do HTML.`,
    noteType: 'text',
    mime: null,
    process: (s) => s
  }
];

// ── Helpers de UI ────────────────────────────────────────────────────────────
function addMsg(role, text) {
  const $msgs = $c.find('#messages');
  const labels = { user: 'Você', ai: 'IA', error: 'Erro', system: '' };
  const cls = { user: 'msg-user', ai: 'msg-ai', error: 'msg-error', system: 'msg-system' };
  const div = $('<div>').addClass('msg ' + (cls[role] || ''));
  if (labels[role]) div.append($('<div>').addClass('msg-label').text(labels[role]));
  div.append($('<div>').addClass('msg-body').text(text));
  $msgs.append(div);
  $msgs.scrollTop($msgs[0].scrollHeight);
}

function setCtx(id, title) {
  ctxNoteId = id;
  $c.find('#ctx-title').text(title || id);
  $c.find('#ctx-id-input').val(id);
  history = [];
  $c.find('#messages').empty();
  addMsg('system', 'Contexto carregado: "' + (title || id) + '"');
}

function setLoading(on) {
  $c.find('#btn-send').prop('disabled', on).text(on ? '...' : 'Enviar');
  $c.find('#typing').toggleClass('visible', on);
}

// ── Config & nota ────────────────────────────────────────────────────────────
async function loadConfig() {
  const notes = await api.searchForNotes('note.title = "AI Chat - Config"');
  if (!notes.length) throw new Error('Nota "AI Chat - Config" não encontrada.');
  const content = await notes[0].getContent();
  const keyMatch = content.match(/openrouter_key:\s*(\S+)/);
  const modelMatch = content.match(/model:\s*(\S+)/);
  if (!keyMatch) throw new Error('Campo openrouter_key não encontrado na nota de config.');
  return {
    key: keyMatch[1],
    model: modelMatch ? modelMatch[1] : 'anthropic/claude-3.5-sonnet'
  };
}

async function loadNote(noteId) {
  if (!noteId) { alert('Informe um ID de nota.'); return; }
  const note = await api.getNote(noteId);
  if (note) setCtx(note.noteId, note.title);
  else alert('Nota não encontrada: ' + noteId);
}

// ── Chat principal ───────────────────────────────────────────────────────────
async function send() {
  const input = $c.find('#user-input');
  const text = input.val().trim();
  if (!text) return;
  input.val('');
  addMsg('user', text);
  history.push({ role: 'user', content: text });
  setLoading(true);

  try {
    const cfg = await loadConfig();

    // Monta o system prompt: persona + contexto da nota (se houver)
    let system = getSystemPrompt();
    if (ctxNoteId) {
      const note = await api.getNote(ctxNoteId);
      if (note) {
        const raw = await note.getContent();
        const plain = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 12000);
        system += '\n\nContexto — nota "' + note.title + '":\n' + plain;
      }
    }

    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + cfg.key,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://trilium.local',
        'X-Title': 'Trilium AI Chat'
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [{ role: 'system', content: system }].concat(history)
      })
    });

    const data = await res.json();
    if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
    const reply = data.choices[0].message.content;
    addMsg('ai', reply);
    history.push({ role: 'assistant', content: reply });

  } catch (e) {
    addMsg('error', e.message);
    history.pop();
  }

  setLoading(false);
}

// ── Salvar conversa ──────────────────────────────────────────────────────────
async function saveNote() {
  if (!history.length) { alert('Nenhuma conversa para salvar.'); return; }
  if (!ctxNoteId) { alert('Carregue uma nota de contexto antes de salvar.'); return; }

  // Inclui o nome da persona usada na nota salva
  const personaLabel = $personaSelect.find('option:selected').text();

  const html = history.map(function(m) {
    const who = m.role === 'user' ? '<strong>Você</strong>' : '<strong>IA</strong>';
    return '<p>' + who + ': ' + m.content.replace(/\n/g, '<br>') + '</p>';
  }).join('<hr>');

  const now = new Date().toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  const metaHtml = '<p><em>Especialista: ' + personaLabel + '</em></p><hr>' + html;

  await api.runOnBackend((parentNoteId, title, content) => {
    api.createNewNote({ parentNoteId, title, content, type: 'text' });
  }, [ctxNoteId, 'Chat IA — ' + now, metaHtml]);

  addMsg('system', 'Conversa salva como nota filha.');
}

// ── Comandos rápidos ─────────────────────────────────────────────────────────
async function runCommand(cmd) {
  if (!ctxNoteId) {
    alert('Carregue uma nota como contexto primeiro.');
    return;
  }

  const $btn = $c.find('#btn-cmd-' + cmd.id);
  const originalLabel = cmd.label;
  $btn.prop('disabled', true).text('⏳ gerando...');

  try {
    const cfg = await loadConfig();
    const note = await api.getNote(ctxNoteId);
    if (!note) throw new Error('Nota de contexto não encontrada.');

    const raw = await note.getContent();
    const plain = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 15000);

    // Comandos rápidos sempre usam um system prompt focado na tarefa,
    // mas incorpora a persona se ela não for a padrão/custom
    const pid = $personaSelect.val();
    let cmdSystem = 'Você é um assistente especializado em processamento de notas de conhecimento. Responda apenas com o conteúdo solicitado, sem comentários adicionais antes ou depois.';
    if (pid !== 'default') {
      const persona = PERSONAS.find(function(p) { return p.id === pid; });
      const personaPrompt = (pid === 'custom') ? getSystemPrompt() : (persona ? persona.prompt : '');
      if (personaPrompt) {
        cmdSystem = personaPrompt + '\n\nResponda apenas com o conteúdo solicitado, sem comentários adicionais antes ou depois.';
      }
    }

    const userMsg = cmd.prompt + '\n\n--- CONTEÚDO DA NOTA "' + note.title + '" ---\n' + plain;

    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + cfg.key,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://trilium.local',
        'X-Title': 'Trilium AI Chat'
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [
          { role: 'system', content: cmdSystem },
          { role: 'user', content: userMsg }
        ]
      })
    });

    const data = await res.json();
    if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));

    const rawContent = data.choices[0].message.content.trim();
    const content = cmd.process(rawContent);
    const childTitle = cmd.childTitle(note.title);

    await api.runOnBackend((parentNoteId, title, noteContent, type, mime) => {
      api.createNewNote({
        parentNoteId,
        title,
        content: noteContent,
        type,
        mime: mime || undefined
      });
    }, [ctxNoteId, childTitle, content, cmd.noteType, cmd.mime]);

    addMsg('system', '✓ Nota criada: "' + childTitle + '"');

  } catch (e) {
    addMsg('error', e.message);
  }

  $btn.prop('disabled', false).text(originalLabel);
}

// ── Event listeners ──────────────────────────────────────────────────────────
$c.find('#btn-send').on('click', send);
$c.find('#btn-save').on('click', saveNote);
$c.find('#btn-clear').on('click', function() {
  history = [];
  $c.find('#messages').empty();
  addMsg('system', 'Conversa limpa.');
});
$c.find('#btn-load').on('click', function() {
  loadNote($c.find('#ctx-id-input').val().trim());
});
$c.find('#btn-active').on('click', async function() {
  const note = api.getActiveContextNote();
  if (note) await loadNote(note.noteId);
  else alert('Nenhuma nota ativa encontrada.');
});
$c.find('#user-input').on('keydown', function(e) {
  if (e.ctrlKey && e.key === 'Enter') send();
});

// Registra handlers dos comandos rápidos
COMMANDS.forEach(function(cmd) {
  $c.find('#btn-cmd-' + cmd.id).on('click', function() { runCommand(cmd); });
});